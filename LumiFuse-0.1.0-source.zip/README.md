# LumiFuse Android

离线 JPG 曝光融合与景深合成 MVP，针对 Panasonic S5M2 包围拍摄、小米 13 Pro 使用场景。

## 已实现的源码功能

- 文件选择器导入 **2～7 张不同的 JPG**：支持 3、5、7 张，不静默截断照片。
- HDR：OpenCV MergeMertens 多尺度曝光融合，生成普通 JPG，**不是 HDR DNG / HDR 显示格式**。
- 景深：局部拉普拉斯能量、平滑权重、归一化融合；逐张读取与累积。
- 自动对齐：640 像素缩略图 ECC 仿射配准，估计轻微位移、旋转和尺度变化。
- 自动裁切：对齐后按公共有效区域最大矩形裁掉黑边。
- 1280 / 2048 / 3072 长边档位，不放大小照片；EXIF 方向校正。
- 原图 / 结果切换，保存 JPG 到系统相册 Pictures/LumiFuse，不覆盖原片。
- 处理进度、重复操作保护、解码失败和内存不足提示。
- 不申请网络权限，不申请整个相册权限。

## 重要限制

此版本是源码 MVP，尚未编译、单元测试或真机验证，当前不包含 APK。算法质量和 API 集成需后续实测。

- HDR 暂无运动物体去鬼影；景深融合可能在遮挡边缘出现光晕，尚非桌面专业软件级。
- 对齐失败会提示错误，不偷偷跳过对齐；三脚架静态照片可手动关闭对齐。
- 三张对焦照片未覆盖的清晰区域，算法补不出细节。
- 建议固定机位、统一白平衡和构图；景深组建议锁定曝光并保证清晰区域重叠。
- 只接受 JPG，且缩放后尺寸和方向必须一致。暂不支持 RW2、相机联机或原尺寸输出。
- HDR 的 MergeMertens 会保留全部缩小后的 RGB 输入，并产生浮点中间缓冲；3072 档不保证内存充足。景深输入逐张处理，但也有浮点累积缓冲。
- 参考原图为第一张的缩略图，合成结果可能已裁切，比较不是精确同区域对照。
- 退到后台不提供前台服务；系统销毁页面会中断处理，重新进入后可再次选择/合成。
- 输出为 8 位 JPG，不保留原始 EXIF、广色域/HDR 元数据。

## 开发环境

- Android Studio、JDK **17**、Android SDK **35**。
- Android Gradle Plugin **8.7.3**，Gradle **8.9**。
- OpenCV **4.10.0**，AndroidX ExifInterface **1.3.7**。
- Java 原生 Android UI + OpenCV 原生库；无需额外 JNI 或 Kotlin 插件。
- 最低 Android 10 / API 29。

在 Android Studio 打开此目录，为项目配置 JDK 17 和 SDK 35。
已附 Gradle 8.9 官方 Wrapper，JAR 已按官方 SHA256 校验；未运行 Wrapper 或构建。
之后经确认可执行 `gradlew.bat assembleDebug`，APK 位于 app/build/outputs/apk/debug/app-debug.apk。

本机默认 Java 是 8；检测到的 SDK 平台为 30 和 36-ext19，35 尚未配置。
当前 Android Studio 的 jbr 检测报缺少 jvm.cfg，因此需选择可用的 JDK 17。
不要将 local.properties、签名密钥、原片或账号凭据提交到仓库。

## 目录职责

- app/src/main/java/com/lumifuse/app/MainActivity.java：UI、状态和相册保存。
- app/src/main/java/com/lumifuse/app/ImageLoader.java：JPG 校验、解码和 EXIF。
- app/src/main/java/com/lumifuse/app/Fusion.java：对齐、两种合成算法和裁切。

保持 KISS / YAGNI：无账号、云端、数据库和相机控制；共享读取与对齐流程，避免按照片数量复制算法。

